package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.TrackingInfo;
import com.example.demo.repo.TrackingInfoRepository;

@Service
public class TrackingInfoServiceImpl {

	@Autowired
	private TrackingInfoRepository trackingInfoRepository;
	
	public TrackingInfo saveTrackingInfo(TrackingInfo trackingInfo) {
		return trackingInfoRepository.save(trackingInfo);
	}
}
