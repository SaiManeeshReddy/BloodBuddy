package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.HospitalInfo;

public interface HospitalInfoRepository extends JpaRepository<HospitalInfo, Integer>{

	public HospitalInfo findHospitalInfoByUserName(String userName);
}
