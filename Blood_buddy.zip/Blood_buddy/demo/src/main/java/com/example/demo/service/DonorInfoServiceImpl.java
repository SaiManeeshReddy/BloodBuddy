package com.example.demo.service;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.DonorInfo;
import com.example.demo.repo.DonorInfoRepository;

@Service
public class DonorInfoServiceImpl {

	@Autowired
	private DonorInfoRepository donorInfoRepository;
	
	
	
	public void addDonorInfo(DonorInfo donorInfo) {
		final String uri = "http://api.openweathermap.org/geo/1.0/direct?"
				+ "q="+donorInfo.getCity()+"&limit=1&appid=88318634fb6812ef8697ea262e7a528b";

		
	    RestTemplate restTemplate = new RestTemplate();
	    String result = restTemplate.getForObject(uri, String.class);
	    System.out.println(result);
	    JSONArray json = new JSONArray(result);
	   // JSONArray jsonArray = json.getJSONArray("");
	    JSONObject js = json.getJSONObject(0);
	    String latitude = String.valueOf(js.getDouble("lat"));
	    String longitude = String.valueOf(js.getDouble("lon"));
	    donorInfo.setDonorLatitude(latitude);
		donorInfo.setDonorLongitude(longitude);
		donorInfoRepository.save(donorInfo);
	}
	
	public List<DonorInfo> getDonors(){
		
	return donorInfoRepository.findAll();	
	}
	
	public DonorInfo getDonorInfo(int donorId) {
		DonorInfo donorInfo = donorInfoRepository.getById(donorId);
		return donorInfo;
	}
	
	public DonorInfo editDonorDonationCount(int donorId) {
		DonorInfo donorInfo = donorInfoRepository.getById(donorId);
		String donationCount = donorInfo.getDonationCount();
		int updatedCount = Integer.valueOf(donationCount) +1;
		donorInfo.setDonationCount(String.valueOf(updatedCount));
		return donorInfoRepository.save(donorInfo);
	}
	
	public List<DonorInfo> getDonorsByLocation(String lat_min,String lat_max,String long_min,String long_max){
		System.out.println(lat_min+" "+lat_max+" "+long_min+" "+long_max);
		System.out.println("select d from donor_info where donor_latitude <= "+ lat_max+" and donor_latitude >= "+ lat_min
				+ " and donor_longitude >= "+ long_min +" and donor_longitude <= " + long_max);
		return donorInfoRepository.getDonorsByLocation(lat_max, lat_min, long_min, long_max);
	}
}
