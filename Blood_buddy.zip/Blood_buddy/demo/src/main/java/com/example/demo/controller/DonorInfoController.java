package com.example.demo.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.DonorInfo;
import com.example.demo.repo.DonorInfoRepository;
import com.example.demo.service.DonorInfoServiceImpl;

@Controller
public class DonorInfoController {

	@Autowired
	DonorInfoServiceImpl donorInfoServiceImpl;
	
	
	
	@RequestMapping("/donor-info")
	public String donorInfo(@RequestParam("fname") String fname,@RequestParam("lname") String lname,
			@RequestParam("DOB") String dob,@RequestParam("addlane") String addlane,
			@RequestParam("city") String city,
			@RequestParam("state") String state,@RequestParam("bgroup") String bgroup,@RequestParam("email") String email,@RequestParam("pnumber") String pnumber) {
		
		DonorInfo donorInfo = new DonorInfo();
		donorInfo.setFirstName(fname);
		donorInfo.setLastName(lname);
		donorInfo.setAddress(addlane);
		donorInfo.setDob(dob);
		donorInfo.setCity(city);
		donorInfo.setState(state);
		donorInfo.setDonationCount("0");
		donorInfo.setBloodGroup(bgroup);
		donorInfo.setEmail(email);
		donorInfo.setPhone(pnumber);
		
		SimpleDateFormat formatter= new SimpleDateFormat("MM-dd-yyyy");
		Date date = new Date(System.currentTimeMillis());
		
		donorInfo.setCreatedDate(formatter.format(date));
		donorInfo.setUpdatedDate(formatter.format(date));
		donorInfoServiceImpl.addDonorInfo(donorInfo);
		return "login";
	}
	
	@RequestMapping("/getdonorsinfo")
	public String getDonorsList(Model model,HttpSession session) {
		List<DonorInfo> donorsList = donorInfoServiceImpl.getDonors();
		model.addAttribute("donorsList", donorsList);
		return "Dashboard";
	}
	
}
