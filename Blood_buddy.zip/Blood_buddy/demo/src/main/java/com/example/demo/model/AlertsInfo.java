package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;

@Entity
@Table(name = "alerts_info")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@JsonView
public class AlertsInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "alert_id")
	private int alert_id;
	
	@Column(name="blood_group")
	private String bloodGroup;
	
	@Column(name="description")
	private String description;
	
	@Column(name="filter")
	private String filter;
	
	@Column(name="receiver_name")
	private String receiverName;
	
	@Column(name="created_date")
	private String createdDate;
	
	@Column(name="hospital_id")
	private int hospitalId;
	
	@Column(name="alert_status")
	private boolean alertStatus;
	
	@Column(name="updated_date")
	private String updatedDate;

	
	public AlertsInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AlertsInfo(int alert_id, String bloodGroup, String description, String filter, String receiverName,
			String createdDate, int hospitalId, boolean alertStatus, String updatedDate) {
		super();
		this.alert_id = alert_id;
		this.bloodGroup = bloodGroup;
		this.description = description;
		this.filter = filter;
		this.receiverName = receiverName;
		this.createdDate = createdDate;
		this.hospitalId = hospitalId;
		this.alertStatus = alertStatus;
		this.updatedDate = updatedDate;
	}

	public int getAlert_id() {
		return alert_id;
	}

	public void setAlert_id(int alert_id) {
		this.alert_id = alert_id;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getReceiverName() {
		return receiverName;
	}

	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public boolean isAlertStatus() {
		return alertStatus;
	}

	public void setAlertStatus(boolean alertStatus) {
		this.alertStatus = alertStatus;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
}
