package com.example.demo.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.AlertsInfo;
import com.example.demo.model.DonorInfo;
import com.example.demo.model.HospitalInfo;
import com.example.demo.service.AlertsServiceImpl;
import com.example.demo.service.DonorInfoServiceImpl;
import com.example.demo.service.HospitalInfoServiceImpl;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.api.v2010.account.MessageCreator;
import com.twilio.type.PhoneNumber;

@Controller
public class LoginController {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	AlertsServiceImpl alertsServiceImpl;
	
	@Autowired
	DonorInfoServiceImpl donorInfoServiceImpl;
	
	@Autowired
	HospitalInfoServiceImpl hospitalInfoServiceImpl;
	
	@Value("${accountSID}")
    private String accountSID;
 
    @Value("${accountAuthToken}")
    private String accountAuthToken;
 
    @Value("${twilloSenderNumber}")
    private String twilloSenderNumber;
	
	@RequestMapping("/sign-in")
	public String login(HttpSession session) {
		//session.invalidate();
		//session.setAttribute("name", "lisa");
		session.setAttribute("hospitalId", 1);
		return "login";
	}
	
	@RequestMapping("/process")
	public String process(HttpSession session,HttpServletRequest request,Model model) {
		
		session.setAttribute("hospitalId", 1);
		String password = null;
		String email = (String)request.getParameter("email");
		HospitalInfo info = hospitalInfoServiceImpl.getHospitalInfoByUserName(email);
	
		if(info != null) {
		password = info.getPassword();
		if(request.getParameter("password").toString().equals(password)) {
			/* if(session.getAttribute("name")!=null) { */
		session.setAttribute("name", info.getUserName());
		
		return "redirect:/alerts-completed";
		}
		else {
			model.addAttribute("error","Password is wrong");
			return "login";	
		}
		}
		else {
			model.addAttribute("error","User Name is wrong");
			return "login";
		}
	}
	@RequestMapping("/alerts-completed")
	public String dashboard(HttpSession session,Model model,HttpServletRequest request) {
		 if(session.getAttribute("name")!=null) {
	//	List<Map<String,Object>> list = jdbcTemplate.queryForList("select * from hospital_info");
			
		List<AlertsInfo> alertsInfoList = alertsServiceImpl.getAlertsByAlertStatus(true);
		model.addAttribute("alertsInfoList", alertsInfoList);
		return "alerts_completed";
		 }
		 else {
			 return "redirect:/sign-in";
		 }
	}
	
	@RequestMapping("/alerts-processing")
	public String alertsProcessing(HttpSession session,Model model) {
		 if(session.getAttribute("name")!=null) {
		List<AlertsInfo> alertsInfoList = alertsServiceImpl.getAlertsByAlertStatus(false);
		model.addAttribute("alertsInfoList", alertsInfoList);
       List<DonorInfo> donorInfoList = donorInfoServiceImpl.getDonors();
       model.addAttribute("donorInfoList", donorInfoList);
		return "alerts_processing";
		 }
		 else {
			// return "login";
			return "redirect:/sign-in";
		 }
			
	}
	
	@RequestMapping("/signup")
	public String signup(HttpSession session) {
		//session.invalidate();
		//System.out.println("blood");
		return "signup";
			
	}
	
	@RequestMapping("/donor-signup")
	public String donorSignup(HttpSession session) {
		//session.invalidate();
		//System.out.println("blood");
		return "donor_signup";
			
	}
	
	@RequestMapping("/logoff")
	public String logoff(HttpSession session) {
		session.invalidate();
		//System.out.println("blood");
		return "login";
			
	}
}
