package com.example.demo.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.AlertsInfo;
import com.example.demo.repo.AlertsInfoRepository;

@Service
public class AlertsServiceImpl {

	@Autowired
	private AlertsInfoRepository alertsInfoRepository;
	
	    public List<AlertsInfo> getAlertsByAlertStatus(boolean alertStatus){
		return alertsInfoRepository.getAlertsByAlertStatus(alertStatus);
	}
	    public AlertsInfo save(AlertsInfo alertsInfo) {
	    	alertsInfo.setAlertStatus(false);
	    	alertsInfo.setHospitalId(1);
	    	SimpleDateFormat formatter= new SimpleDateFormat("MM-dd-yyyy");
			Date date = new Date(System.currentTimeMillis());
			
			alertsInfo.setCreatedDate(formatter.format(date));
			alertsInfo.setUpdatedDate(formatter.format(date));
	    	return alertsInfoRepository.save(alertsInfo);
	    }
	    
	    public AlertsInfo getAlert(int alertId) {
	    	return alertsInfoRepository.getById(alertId);
	    }
	    
	    public AlertsInfo editAlert(int alertId,String filter) {
	    	AlertsInfo alertsInfo = getAlert(alertId);
	    	alertsInfo.setFilter(filter);
	    	return alertsInfoRepository.save(alertsInfo);
	    }
	    
	    public AlertsInfo closeAlert(int alertId) {
	    	AlertsInfo alertsInfo = getAlert(alertId);
	    	alertsInfo.setAlertStatus(true);
	    	return alertsInfoRepository.save(alertsInfo);
	    }
}
