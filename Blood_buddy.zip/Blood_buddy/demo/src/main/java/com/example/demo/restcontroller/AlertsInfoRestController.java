package com.example.demo.restcontroller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.AlertsInfo;
import com.example.demo.model.DonorInfo;
import com.example.demo.model.HospitalInfo;
import com.example.demo.model.Numbers;
import com.example.demo.model.TrackingInfo;
import com.example.demo.service.AlertsServiceImpl;
import com.example.demo.service.DonorInfoServiceImpl;
import com.example.demo.service.HospitalInfoServiceImpl;
import com.example.demo.service.TrackingInfoServiceImpl;

@RestController
@Transactional
public class AlertsInfoRestController {
	
	@Autowired
	private AlertsServiceImpl alertsServiceImpl;
	
	@Autowired
	private DonorInfoServiceImpl donorInfoServiceImpl;
	
	@Autowired
	private HospitalInfoServiceImpl hospitalInfoServiceImpl;
	
	@Autowired
	private TrackingInfoServiceImpl trackingInfoServiceImpl;
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@RequestMapping("/triggeralert/{name}/{description}/{blood}/{filter}")
	public AlertsInfo donorSignup(@PathVariable("name") String name, 
			@PathVariable("description") String description,@PathVariable("blood") String blood
			,@PathVariable("filter") String filter,HttpSession session) {
		List<String> list = new ArrayList();
		  RestTemplate restTemplate = new RestTemplate();
		AlertsInfo alertsInfo = new AlertsInfo();
		alertsInfo.setReceiverName(name);
		alertsInfo.setDescription(description);
		alertsInfo.setBloodGroup(blood);
		alertsInfo.setFilter(filter);
		AlertsInfo alertsnewInfo = alertsServiceImpl.save(alertsInfo);
		int hospitalId = (int) session.getAttribute("hospitalId");
		int alertId = alertsnewInfo.getAlert_id();
		
		            	
		        		HospitalInfo info = hospitalInfoServiceImpl.getHospitalInfoById(hospitalId);
		        		double lat = Double.valueOf(info.getHospitalLatitude());
		        		double lon = Double.valueOf(info.getHospitalLongitude());
		        		double lat_min,lat_max,long_min,long_max;
		        		if(filter.equals("15")) {
		        			lat_min = lat - 0.25;
		        			lat_max = lat + 0.25;
		        			long_min = lon - 0.25;
		        			long_max = lon + 0.25;
		        		}
		        		else if(filter.equals("20")) {
		        			lat_min = lat - 0.32;
		        			lat_max = lat + 0.32;
		        			long_min = lon - 0.32;
		        			long_max = lon + 0.32;
		        		}
		        		else {
		        			lat_min = lat - 0.50;
		        			lat_max = lat + 0.50;
		        			long_min = lon - 0.50;
		        			long_max = lon + 0.50;
		        		}
		        	
		        		List<Map<String,Object>> donorsInfo = jdbcTemplate.
		        				queryForList("select * from donor_info where blood_group = '"+blood+"' and donor_latitude <= " + lat_max+" and donor_latitude >= " + lat_min +" and donor_longitude >= "+ long_min+" and donor_longitude <= "+long_max);
						
		        		for(int i=0;i<donorsInfo.size();i++) {
		        			Map<String,Object> map = donorsInfo.get(i);
		        			if(blood.equals((String) map.get("blood_group"))) {
		        			Integer donorId = (Integer) map.get("donor_id");
		        			list.add((String)map.get("phone"));
		        			TrackingInfo trackingInfo = new TrackingInfo();
		        			trackingInfo.setAlertId(alertId);
		        			trackingInfo.setDonorId(donorId);
		        			trackingInfo.setHospitalId(hospitalId);
		        			trackingInfo.setTrackingStatus(true);
		        			trackingInfoServiceImpl.saveTrackingInfo(trackingInfo);
		        		}
		        		}
		        		Numbers numbers = new Numbers();
		        		numbers.setList(list);
		        		numbers.setMessage(description);
						
						  new java.util.Timer().schedule( new java.util.TimerTask() {
						  
						  @Override public void run() {
						  if(list.size()>0) {
						  HttpHeaders headers = new HttpHeaders();
						  headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
						  HttpEntity<Numbers> entity = new HttpEntity<Numbers>(numbers,headers);
						  restTemplate.exchange( "http://localhost:8086/messages", HttpMethod.POST,
						  entity, String.class);
						  }
						  } 
						  }, 
								  2000 );
						 
		
		return alertsnewInfo;	
	}
	
	@RequestMapping("/editalert/{alertId}/{filter}")
	public AlertsInfo editAlert(@PathVariable("alertId") String alertId,
			@PathVariable("filter") String filter,HttpSession session) {
		List<String> list = new ArrayList();
		  RestTemplate restTemplate = new RestTemplate();
		AlertsInfo alertsInfo = alertsServiceImpl.editAlert(Integer.valueOf(alertId), filter);
		String description = alertsInfo.getDescription();
		int hospitalId = (int) session.getAttribute("hospitalId");
		HospitalInfo info = hospitalInfoServiceImpl.getHospitalInfoById(hospitalId);
		double lat = Double.valueOf(info.getHospitalLatitude());
		double lon = Double.valueOf(info.getHospitalLongitude());
		double lat_min,lat_max,long_min,long_max;
		if(filter.equals("15")) {
			lat_min = lat - 0.25;
			lat_max = lat + 0.25;
			long_min = lon - 0.25;
			long_max = lon + 0.25;
		}
		else if(filter.equals("20")) {
			lat_min = lat - 0.32;
			lat_max = lat + 0.32;
			long_min = lon - 0.32;
			long_max = lon + 0.32;
		}
		else {
			lat_min = lat - 0.50;
			lat_max = lat + 0.50;
			long_min = lon - 0.50;
			long_max = lon + 0.50;
		}
	
		List<Map<String,Object>> donorsInfo = jdbcTemplate.
				queryForList("select * from donor_info where donor_latitude <= " + lat_max+" and donor_latitude >= " + lat_min +" and donor_longitude >= "+ long_min+" and donor_longitude <= "+long_max);
		
		for(int i=0;i<donorsInfo.size();i++) {
			Map<String,Object> map = donorsInfo.get(i);
			Integer donorId = (Integer) map.get("donor_id");
			list.add((String)map.get("phone"));
			TrackingInfo trackingInfo = new TrackingInfo();
			trackingInfo.setAlertId(Integer.valueOf(alertId));
			trackingInfo.setDonorId(donorId);
			trackingInfo.setHospitalId(hospitalId);
			trackingInfo.setTrackingStatus(true);
			trackingInfoServiceImpl.saveTrackingInfo(trackingInfo);
		
	}
		Numbers numbers = new Numbers();
		numbers.setList(list);
		numbers.setMessage(description);
		  new java.util.Timer().schedule( new java.util.TimerTask() {
    		  
    		  @Override public void run() {
    		 
    			  HttpHeaders headers = new HttpHeaders();
    		      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    		      HttpEntity<Numbers> entity = new HttpEntity<Numbers>(numbers,headers);
    		      restTemplate.exchange(
    		    	         "http://localhost:8086/messages", HttpMethod.POST, entity, String.class);
       }
    }, 
    2000 
);
		return alertsInfo;
	}
	
	@RequestMapping("/closealert/{alertId}/{donor}")
	public AlertsInfo closeAlert(@PathVariable("alertId") String alertId,
			@PathVariable("donor") String donor) {
		donorInfoServiceImpl.editDonorDonationCount(Integer.valueOf(donor));
		return alertsServiceImpl.closeAlert(Integer.valueOf(alertId));
	}
}
